hostname
df -Th /
date
